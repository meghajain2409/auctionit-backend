'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

const API = process.env.NEXT_PUBLIC_API_URL;

const STATUS_LABELS = {
  published: { text: 'Upcoming', color: 'bg-blue-500/20 text-blue-300' },
  emd_collection: { text: 'Registration Open', color: 'bg-yellow-500/20 text-yellow-300' },
  live: { text: '● LIVE', color: 'bg-green-500/20 text-green-300 animate-pulse' },
  ended: { text: 'Ended', color: 'bg-red-500/20 text-red-300' },
  awarded: { text: 'Awarded', color: 'bg-purple-500/20 text-purple-300' },
};

export default function BidderAuctionsPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [auctions, setAuctions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('');
  const [expandedAuction, setExpandedAuction] = useState(null);
  const [lots, setLots] = useState({});
  const [lotsLoading, setLotsLoading] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    if (!token || !userData) { router.push('/login'); return; }
    setUser(JSON.parse(userData));
    fetchAuctions();
  }, []);

  const fetchAuctions = async () => {
    try {
      const res = await fetch(`${API}/api/auctions?limit=50`);
      const data = await res.json();
      if (data.success) {
        setAuctions(data.data.auctions || data.data || []);
      }
    } catch (err) {
      console.error('Fetch auctions error:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchLots = async (auctionId) => {
    if (lots[auctionId]) return; // already fetched
    setLotsLoading(auctionId);
    try {
      const res = await fetch(`${API}/api/auctions/${auctionId}/lots`);
      const data = await res.json();
      if (data.success) {
        setLots(prev => ({ ...prev, [auctionId]: data.data || [] }));
      }
    } catch (err) {
      console.error('Fetch lots error:', err);
    } finally {
      setLotsLoading('');
    }
  };

  const toggleAuction = (auctionId) => {
    if (expandedAuction === auctionId) {
      setExpandedAuction(null);
    } else {
      setExpandedAuction(auctionId);
      fetchLots(auctionId);
    }
  };

  const getTimeRemaining = (endTime) => {
    if (!endTime) return null;
    const diff = new Date(endTime) - new Date();
    if (diff <= 0) return 'Ended';
    const hours = Math.floor(diff / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);
    if (hours > 24) return `${Math.floor(hours / 24)}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
  };

  const formatDate = (d) => {
    if (!d) return '—';
    return new Date(d).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  };

  const filtered = auctions.filter(a => {
    if (filter && a.status !== filter) return false;
    if (search && !a.title?.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const liveAuctions = filtered.filter(a => a.status === 'live');
  const upcomingAuctions = filtered.filter(a => ['published', 'emd_collection'].includes(a.status));
  const pastAuctions = filtered.filter(a => ['ended', 'awarded'].includes(a.status));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 pb-20 md:pb-8">
      {/* Header */}
      <header className="border-b border-white/5 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white text-sm font-bold">A</span>
              </div>
              <span className="text-white font-bold text-lg">AuctionIt</span>
            </div>
            <nav className="hidden md:flex items-center gap-1">
              <Link href="/bidder/dashboard" className="px-4 py-2 text-sm text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition">Dashboard</Link>
              <Link href="/bidder/auctions" className="px-4 py-2 text-sm font-medium text-white bg-white/10 rounded-lg">Auctions</Link>
              <Link href="/bidder/bids" className="px-4 py-2 text-sm text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition">My Bids</Link>
              <Link href="/bidder/profile" className="px-4 py-2 text-sm text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition">Profile</Link>
            </nav>
            <div className="flex items-center gap-3">
              <span className="text-sm text-white/60 hidden sm:block">{user?.name}</span>
              <button onClick={() => { localStorage.clear(); router.push('/login'); }}
                className="text-sm text-red-400 hover:text-red-300 px-3 py-2 rounded-lg hover:bg-red-500/10 transition">
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white">Auctions</h1>
          <p className="text-sm text-white/40 mt-1">Browse and bid on industrial scrap auctions</p>
        </div>

        {/* Search + Filter */}
        <div className="flex flex-col sm:flex-row gap-3 mb-8">
          <div className="relative flex-1">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input type="text" placeholder="Search auctions..."
              value={search} onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            />
          </div>
          <div className="flex gap-2">
            {[
              { value: '', label: 'All' },
              { value: 'live', label: '● Live' },
              { value: 'published', label: 'Upcoming' },
              { value: 'ended', label: 'Ended' },
            ].map(f => (
              <button key={f.value} onClick={() => setFilter(f.value)}
                className={`px-4 py-2.5 text-sm rounded-xl transition whitespace-nowrap ${
                  filter === f.value
                    ? 'bg-blue-600 text-white font-medium'
                    : 'bg-white/5 text-white/50 hover:text-white hover:bg-white/10'
                }`}>
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 bg-white/5 border border-white/10 rounded-2xl">
            <div className="text-4xl mb-3">🏷️</div>
            <p className="text-white/60 font-medium">No auctions available</p>
            <p className="text-xs text-white/30 mt-1">Check back soon for upcoming auctions</p>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Live Auctions */}
            {liveAuctions.length > 0 && (
              <section>
                <h2 className="text-sm font-semibold text-green-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                  Live Now
                </h2>
                <div className="space-y-4">
                  {liveAuctions.map(auction => (
                    <AuctionCard
                      key={auction.id} auction={auction}
                      expanded={expandedAuction === auction.id}
                      onToggle={() => toggleAuction(auction.id)}
                      lots={lots[auction.id]} lotsLoading={lotsLoading === auction.id}
                      getTimeRemaining={getTimeRemaining} formatDate={formatDate}
                      isLive
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Upcoming */}
            {upcomingAuctions.length > 0 && (
              <section>
                <h2 className="text-sm font-semibold text-blue-400 uppercase tracking-wider mb-4">Upcoming</h2>
                <div className="space-y-4">
                  {upcomingAuctions.map(auction => (
                    <AuctionCard
                      key={auction.id} auction={auction}
                      expanded={expandedAuction === auction.id}
                      onToggle={() => toggleAuction(auction.id)}
                      lots={lots[auction.id]} lotsLoading={lotsLoading === auction.id}
                      getTimeRemaining={getTimeRemaining} formatDate={formatDate}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Past */}
            {pastAuctions.length > 0 && (
              <section>
                <h2 className="text-sm font-semibold text-white/40 uppercase tracking-wider mb-4">Past Auctions</h2>
                <div className="space-y-4">
                  {pastAuctions.map(auction => (
                    <AuctionCard
                      key={auction.id} auction={auction}
                      expanded={expandedAuction === auction.id}
                      onToggle={() => toggleAuction(auction.id)}
                      lots={lots[auction.id]} lotsLoading={lotsLoading === auction.id}
                      getTimeRemaining={getTimeRemaining} formatDate={formatDate}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 bg-slate-950/95 backdrop-blur-xl border-t border-white/5">
        <div className="flex items-center justify-around h-16">
          {[
            { href: '/bidder/dashboard', label: 'Home', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
            { href: '/bidder/auctions', label: 'Auctions', icon: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z', active: true },
            { href: '/bidder/bids', label: 'My Bids', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
            { href: '/bidder/profile', label: 'Profile', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
          ].map(item => (
            <Link key={item.href} href={item.href}
              className={`flex flex-col items-center gap-1 px-3 py-1 ${item.active ? 'text-blue-400' : 'text-white/30'}`}>
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d={item.icon} />
              </svg>
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}

function AuctionCard({ auction, expanded, onToggle, lots, lotsLoading, getTimeRemaining, formatDate, isLive }) {
  const statusInfo = STATUS_LABELS[auction.status] || { text: auction.status, color: 'bg-gray-500/20 text-gray-300' };
  const timeLeft = getTimeRemaining(auction.end_time);

  return (
    <div className={`bg-white/5 border rounded-xl overflow-hidden transition ${
      isLive ? 'border-green-500/30 shadow-lg shadow-green-500/5' : 'border-white/10'
    }`}>
      <div className="p-5 cursor-pointer" onClick={onToggle}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-white font-semibold">{auction.title}</h3>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${statusInfo.color}`}>
                {statusInfo.text}
              </span>
            </div>
            <div className="flex flex-wrap gap-4 text-xs text-white/40">
              {auction.auction_number && <span className="font-mono">#{auction.auction_number}</span>}
              <span>📅 {formatDate(auction.start_time)}</span>
              {auction.total_lots > 0 && <span>📦 {auction.total_lots} lots</span>}
              {auction.emd_amount > 0 && <span>💰 EMD ₹{Number(auction.emd_amount).toLocaleString('en-IN')}</span>}
              {auction.material_location && <span>📍 {auction.material_location}</span>}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isLive && timeLeft && (
              <div className="text-right">
                <p className="text-xs text-white/40">Time left</p>
                <p className="text-lg font-bold text-green-400 font-mono">{timeLeft}</p>
              </div>
            )}
            <svg className={`w-5 h-5 text-white/30 transition-transform ${expanded ? 'rotate-180' : ''}`}
              fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>
      </div>

      {/* Expanded Lots */}
      {expanded && (
        <div className="border-t border-white/5 px-5 pb-5">
          {lotsLoading ? (
            <div className="flex justify-center py-6">
              <div className="animate-spin h-5 w-5 border-2 border-blue-500 border-t-transparent rounded-full"></div>
            </div>
          ) : !lots || lots.length === 0 ? (
            <p className="text-white/30 text-sm py-6 text-center">No lots in this auction</p>
          ) : (
            <div className="space-y-3 pt-4">
              {lots.map(lot => (
                <div key={lot.id} className="bg-white/[0.03] border border-white/5 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs text-blue-400 font-mono">{lot.lot_number}</span>
                        {lot.category_name && (
                          <span className="px-2 py-0.5 rounded text-[10px] bg-white/5 text-white/50">{lot.category_name}</span>
                        )}
                      </div>
                      <p className="text-white font-medium text-sm">{lot.title}</p>
                      {lot.description && <p className="text-white/30 text-xs mt-1">{lot.description}</p>}
                      <div className="flex flex-wrap gap-3 mt-2 text-xs text-white/40">
                        {lot.quantity && <span>{lot.quantity} {lot.unit}</span>}
                        {lot.material_grade && <span>Grade: {lot.material_grade}</span>}
                        {lot.location && <span>📍 {lot.location}</span>}
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0 ml-4">
                      <p className="text-xs text-white/40">
                        {isLive && parseInt(lot.total_bids) > 0 ? 'Current Price' : 'Start Price'}
                      </p>
                      <p className="text-xl font-bold text-white">
                        ₹{Number(isLive && lot.highest_bid ? lot.highest_bid : lot.start_price).toLocaleString('en-IN')}
                      </p>
                      {lot.total_bids > 0 && (
                        <p className="text-xs text-white/40 mt-0.5">{lot.total_bids} bids</p>
                      )}
                      <p className="text-[10px] text-white/30">{lot.price_unit || 'per MT'}</p>
                    </div>
                  </div>
                </div>
              ))}

              {isLive && (
                <div className="pt-2">
                  <Link href={`/bidder/auctions/${auction.id}/live`}
                    className="block w-full text-center px-4 py-3 bg-green-600 hover:bg-green-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-green-600/20 transition">
                    🔴 Enter Live Auction
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
