'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

const API = process.env.NEXT_PUBLIC_API_URL;

function getToken() {
  return localStorage.getItem('token');
}

function authHeaders() {
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${getToken()}`
  };
}

const STATUS_COLORS = {
  draft: 'bg-gray-500/20 text-gray-300',
  published: 'bg-blue-500/20 text-blue-300',
  emd_collection: 'bg-yellow-500/20 text-yellow-300',
  live: 'bg-green-500/20 text-green-300',
  ended: 'bg-red-500/20 text-red-300',
  awarded: 'bg-purple-500/20 text-purple-300',
  cancelled: 'bg-gray-500/20 text-gray-400',
};

export default function AdminAuctionsPage() {
  const router = useRouter();
  const [auctions, setAuctions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showLots, setShowLots] = useState(null); // auctionId
  const [lots, setLots] = useState([]);
  const [lotsLoading, setLotsLoading] = useState(false);
  const [error, setError] = useState('');
  const [actionLoading, setActionLoading] = useState('');
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  // Create Auction form
  const [form, setForm] = useState({
    title: '', description: '', startTime: '', endTime: '',
    emdAmount: '0', materialLocation: '', termsAndConditions: ''
  });

  // Add Lot form
  const [lotForm, setLotForm] = useState({
    title: '', description: '', startPrice: '', minIncrement: '100',
    quantity: '', unit: 'MT', materialGrade: '', location: ''
  });

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (!user) { router.push('/login'); return; }
    const parsed = JSON.parse(user);
    if (!['super_admin', 'account_manager'].includes(parsed.role)) {
      router.push('/login'); return;
    }
    fetchAuctions();
  }, []);

  const fetchAuctions = async () => {
    try {
      const res = await fetch(`${API}/api/auctions?limit=50`, { headers: authHeaders() });
      const data = await res.json();
      if (data.success) {
        setAuctions(data.data.auctions || data.data || []);
      }
    } catch (err) {
      console.error('Fetch auctions error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Also fetch draft auctions (they're excluded from public list)
  useEffect(() => {
    const fetchDrafts = async () => {
      try {
        const res = await fetch(`${API}/api/auctions?status=draft&limit=50`, { headers: authHeaders() });
        const data = await res.json();
        if (data.success) {
          const drafts = data.data.auctions || data.data || [];
          setAuctions(prev => {
            const ids = new Set(prev.map(a => a.id));
            return [...prev, ...drafts.filter(d => !ids.has(d.id))];
          });
        }
      } catch (err) { /* ignore */ }
    };
    fetchDrafts();
  }, [loading]);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError('');
    setActionLoading('create');
    try {
      const res = await fetch(`${API}/api/auctions`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({
          title: form.title,
          description: form.description,
          startTime: new Date(form.startTime).toISOString(),
          endTime: new Date(form.endTime).toISOString(),
          emdAmount: parseFloat(form.emdAmount) || 0,
          materialLocation: form.materialLocation,
          termsAndConditions: form.termsAndConditions
        })
      });
      const data = await res.json();
      if (data.success) {
        setShowCreate(false);
        setForm({ title: '', description: '', startTime: '', endTime: '', emdAmount: '0', materialLocation: '', termsAndConditions: '' });
        fetchAuctions();
      } else {
        setError(data.message);
      }
    } catch (err) {
      setError('Network error');
    } finally {
      setActionLoading('');
    }
  };

  const handleAction = async (auctionId, action, body = {}) => {
    setActionLoading(`${action}-${auctionId}`);
    try {
      const res = await fetch(`${API}/api/auctions/${auctionId}/${action}`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (data.success) {
        fetchAuctions();
      } else {
        alert(data.message || `Failed to ${action}`);
      }
    } catch (err) {
      alert('Network error');
    } finally {
      setActionLoading('');
    }
  };

  const fetchLots = async (auctionId) => {
    setLotsLoading(true);
    try {
      const res = await fetch(`${API}/api/auctions/${auctionId}/lots`, { headers: authHeaders() });
      const data = await res.json();
      if (data.success) {
        setLots(data.data || []);
      }
    } catch (err) {
      console.error('Fetch lots error:', err);
    } finally {
      setLotsLoading(false);
    }
  };

  const handleAddLot = async (e) => {
    e.preventDefault();
    setError('');
    setActionLoading('addlot');
    try {
      const res = await fetch(`${API}/api/auctions/${showLots}/lots`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({
          title: lotForm.title,
          description: lotForm.description,
          startPrice: parseFloat(lotForm.startPrice),
          minIncrement: parseFloat(lotForm.minIncrement) || 100,
          quantity: parseFloat(lotForm.quantity) || null,
          unit: lotForm.unit,
          materialGrade: lotForm.materialGrade,
          location: lotForm.location
        })
      });
      const data = await res.json();
      if (data.success) {
        setLotForm({ title: '', description: '', startPrice: '', minIncrement: '100', quantity: '', unit: 'MT', materialGrade: '', location: '' });
        fetchLots(showLots);
      } else {
        setError(data.message);
      }
    } catch (err) {
      setError('Network error');
    } finally {
      setActionLoading('');
    }
  };

  const handleDeleteLot = async (auctionId, lotId) => {
    if (!confirm('Delete this lot?')) return;
    try {
      const res = await fetch(`${API}/api/auctions/${auctionId}/lots/${lotId}`, {
        method: 'DELETE',
        headers: authHeaders()
      });
      const data = await res.json();
      if (data.success) fetchLots(auctionId);
      else alert(data.message);
    } catch (err) {
      alert('Network error');
    }
  };

  const filteredAuctions = auctions.filter(a => {
    if (filterStatus && a.status !== filterStatus) return false;
    if (search && !a.title?.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const formatDate = (d) => {
    if (!d) return '—';
    return new Date(d).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-white/5 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white text-sm font-bold">A</span>
              </div>
              <span className="text-white font-bold text-lg">AuctionIt</span>
              <span className="text-white/30 text-sm ml-2">Admin</span>
            </div>
            <nav className="hidden md:flex items-center gap-1">
              <Link href="/admin/clients" className="px-4 py-2 text-sm text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition">Clients</Link>
              <Link href="/admin/materials" className="px-4 py-2 text-sm text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition">Materials</Link>
              <Link href="/admin/auctions" className="px-4 py-2 text-sm font-medium text-white bg-white/10 rounded-lg">Auctions</Link>
            </nav>
            <button onClick={() => { localStorage.clear(); router.push('/login'); }}
              className="text-sm text-red-400 hover:text-red-300 px-3 py-2 rounded-lg hover:bg-red-500/10 transition">
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Title + Actions */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white">Auction Management</h1>
            <p className="text-sm text-white/40 mt-1">{auctions.length} auctions total</p>
          </div>
          <button onClick={() => setShowCreate(true)}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold rounded-xl shadow-lg shadow-blue-600/20 transition">
            + Create Auction
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <input
            type="text" placeholder="Search auctions..."
            value={search} onChange={(e) => setSearch(e.target.value)}
            className="flex-1 px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          />
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50">
            <option value="">All Status</option>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="live">Live</option>
            <option value="ended">Ended</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        {/* Auctions List */}
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
          </div>
        ) : filteredAuctions.length === 0 ? (
          <div className="text-center py-20 bg-white/5 border border-white/10 rounded-2xl">
            <div className="text-4xl mb-3">🏷️</div>
            <p className="text-white/60 font-medium">No auctions yet</p>
            <p className="text-xs text-white/30 mt-1">Create your first auction to get started</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredAuctions.map((auction) => (
              <div key={auction.id} className="bg-white/5 border border-white/10 rounded-xl p-5 hover:bg-white/[0.07] transition">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-white font-semibold text-lg">{auction.title}</h3>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[auction.status] || 'bg-gray-500/20 text-gray-300'}`}>
                        {auction.status?.replace('_', ' ').toUpperCase()}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-xs text-white/40">
                      {auction.auction_number && <span>#{auction.auction_number}</span>}
                      <span>Start: {formatDate(auction.start_time)}</span>
                      <span>End: {formatDate(auction.end_time)}</span>
                      {auction.total_lots !== undefined && <span>{auction.total_lots} lots</span>}
                      {auction.emd_amount > 0 && <span>EMD: ₹{Number(auction.emd_amount).toLocaleString('en-IN')}</span>}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {/* Manage Lots */}
                    <button onClick={() => { setShowLots(auction.id); fetchLots(auction.id); }}
                      className="px-3 py-1.5 text-xs font-medium text-blue-300 bg-blue-500/10 hover:bg-blue-500/20 rounded-lg transition">
                      📦 Lots
                    </button>

                    {/* Status Actions */}
                    {auction.status === 'draft' && (
                      <button
                        onClick={() => handleAction(auction.id, 'publish')}
                        disabled={actionLoading === `publish-${auction.id}`}
                        className="px-3 py-1.5 text-xs font-medium text-green-300 bg-green-500/10 hover:bg-green-500/20 rounded-lg transition disabled:opacity-50">
                        {actionLoading === `publish-${auction.id}` ? '...' : '📢 Publish'}
                      </button>
                    )}
                    {['published', 'emd_collection'].includes(auction.status) && (
                      <button
                        onClick={() => handleAction(auction.id, 'go-live')}
                        disabled={actionLoading === `go-live-${auction.id}`}
                        className="px-3 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 rounded-lg transition disabled:opacity-50">
                        {actionLoading === `go-live-${auction.id}` ? '...' : '🔴 Go Live'}
                      </button>
                    )}
                    {auction.status === 'live' && (
                      <button
                        onClick={() => handleAction(auction.id, 'end')}
                        disabled={actionLoading === `end-${auction.id}`}
                        className="px-3 py-1.5 text-xs font-medium text-red-300 bg-red-500/10 hover:bg-red-500/20 rounded-lg transition disabled:opacity-50">
                        {actionLoading === `end-${auction.id}` ? '...' : '⏹ End'}
                      </button>
                    )}
                    {!['ended', 'cancelled', 'completed'].includes(auction.status) && (
                      <button
                        onClick={() => {
                          const reason = prompt('Enter cancellation reason:');
                          if (reason) handleAction(auction.id, 'cancel', { reason });
                        }}
                        className="px-3 py-1.5 text-xs font-medium text-gray-400 bg-white/5 hover:bg-white/10 rounded-lg transition">
                        ✕ Cancel
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* ── CREATE AUCTION MODAL ── */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/10 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">Create Auction</h2>
              <button onClick={() => setShowCreate(false)} className="text-white/40 hover:text-white text-xl">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-blue-200/80 mb-1.5">Title *</label>
                <input type="text" required value={form.title}
                  onChange={(e) => setForm({...form, title: e.target.value})}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  placeholder="e.g. Tata Steel Scrap Auction - March 2026"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-blue-200/80 mb-1.5">Description</label>
                <textarea value={form.description}
                  onChange={(e) => setForm({...form, description: e.target.value})}
                  rows={3}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none"
                  placeholder="Auction description..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-blue-200/80 mb-1.5">Start Time *</label>
                  <input type="datetime-local" required value={form.startTime}
                    onChange={(e) => setForm({...form, startTime: e.target.value})}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 [color-scheme:dark]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-blue-200/80 mb-1.5">End Time *</label>
                  <input type="datetime-local" required value={form.endTime}
                    onChange={(e) => setForm({...form, endTime: e.target.value})}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 [color-scheme:dark]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-blue-200/80 mb-1.5">EMD Amount (₹)</label>
                  <input type="number" value={form.emdAmount}
                    onChange={(e) => setForm({...form, emdAmount: e.target.value})}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-blue-200/80 mb-1.5">Location</label>
                  <input type="text" value={form.materialLocation}
                    onChange={(e) => setForm({...form, materialLocation: e.target.value})}
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                    placeholder="Material location"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-blue-200/80 mb-1.5">Terms & Conditions</label>
                <textarea value={form.termsAndConditions}
                  onChange={(e) => setForm({...form, termsAndConditions: e.target.value})}
                  rows={2}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none"
                  placeholder="Terms and conditions..."
                />
              </div>

              {error && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-300 text-sm">{error}</div>
              )}

              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowCreate(false)}
                  className="flex-1 px-4 py-2.5 bg-white/5 border border-white/10 text-white/60 rounded-xl text-sm font-medium hover:bg-white/10 transition">
                  Cancel
                </button>
                <button type="submit" disabled={actionLoading === 'create'}
                  className="flex-1 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-blue-600/20 transition disabled:opacity-50">
                  {actionLoading === 'create' ? 'Creating...' : 'Create Auction'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── LOT MANAGEMENT MODAL ── */}
      {showLots && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">Manage Lots</h2>
              <button onClick={() => { setShowLots(null); setLots([]); setError(''); }} className="text-white/40 hover:text-white text-xl">✕</button>
            </div>

            {/* Existing Lots */}
            {lotsLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin h-6 w-6 border-3 border-blue-500 border-t-transparent rounded-full"></div>
              </div>
            ) : lots.length > 0 ? (
              <div className="space-y-3 mb-6">
                {lots.map((lot) => (
                  <div key={lot.id} className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-blue-400 font-mono">{lot.lot_number}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${STATUS_COLORS[lot.status] || 'bg-gray-500/20 text-gray-300'}`}>
                          {lot.status?.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-white font-medium text-sm mt-1">{lot.title}</p>
                      <div className="flex gap-3 text-xs text-white/40 mt-1">
                        <span>Start: ₹{Number(lot.start_price).toLocaleString('en-IN')}</span>
                        {lot.current_price && <span>Current: ₹{Number(lot.current_price).toLocaleString('en-IN')}</span>}
                        {lot.quantity && <span>{lot.quantity} {lot.unit}</span>}
                        <span>{lot.total_bids || 0} bids</span>
                      </div>
                    </div>
                    {['draft', 'active'].includes(lot.status) && (
                      <button onClick={() => handleDeleteLot(showLots, lot.id)}
                        className="text-red-400 hover:text-red-300 text-xs px-2 py-1 hover:bg-red-500/10 rounded transition">
                        🗑
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 mb-6 bg-white/[0.02] border border-dashed border-white/10 rounded-xl">
                <p className="text-white/40 text-sm">No lots yet — add your first lot below</p>
              </div>
            )}

            {/* Add Lot Form */}
            <div className="border-t border-white/10 pt-6">
              <h3 className="text-sm font-semibold text-white mb-4">Add New Lot</h3>
              <form onSubmit={handleAddLot} className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <input type="text" required value={lotForm.title}
                      onChange={(e) => setLotForm({...lotForm, title: e.target.value})}
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      placeholder="Lot title (e.g. MS Scrap - Heavy Melting)"
                    />
                  </div>
                  <div>
                    <input type="number" required value={lotForm.startPrice}
                      onChange={(e) => setLotForm({...lotForm, startPrice: e.target.value})}
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      placeholder="Start price (₹)"
                    />
                  </div>
                  <div>
                    <input type="number" value={lotForm.minIncrement}
                      onChange={(e) => setLotForm({...lotForm, minIncrement: e.target.value})}
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      placeholder="Min increment (₹)"
                    />
                  </div>
                  <div>
                    <input type="number" value={lotForm.quantity}
                      onChange={(e) => setLotForm({...lotForm, quantity: e.target.value})}
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      placeholder="Quantity"
                    />
                  </div>
                  <div>
                    <select value={lotForm.unit} onChange={(e) => setLotForm({...lotForm, unit: e.target.value})}
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50">
                      <option value="MT">MT</option>
                      <option value="KG">KG</option>
                      <option value="Pieces">Pieces</option>
                      <option value="Lots">Lots</option>
                    </select>
                  </div>
                  <div>
                    <input type="text" value={lotForm.materialGrade}
                      onChange={(e) => setLotForm({...lotForm, materialGrade: e.target.value})}
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      placeholder="Material grade"
                    />
                  </div>
                  <div>
                    <input type="text" value={lotForm.location}
                      onChange={(e) => setLotForm({...lotForm, location: e.target.value})}
                      className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      placeholder="Location"
                    />
                  </div>
                </div>

                {error && (
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-300 text-sm">{error}</div>
                )}

                <button type="submit" disabled={actionLoading === 'addlot'}
                  className="w-full px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-blue-600/20 transition disabled:opacity-50">
                  {actionLoading === 'addlot' ? 'Adding...' : '+ Add Lot'}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
